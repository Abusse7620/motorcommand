# motorcommand

/motor command with a cooldown
